# Read Me Template

![Project Image](project-image-url)

> This is a ReadMe template to help save you time and effort.
># It's a custom post type template for doing quotes

The template includes name address telephone number email address and it's really designed for a cleaning quote we're houses
 you could add or take Different blocks away different fields to adapt it to your needs 

 JavaScript to add hey we want some help with that would be appreciated but this is a work in progress all help would be appreciated committing minor bug fixes will be done soon 

You've still got a clean out the project for all the working folders
---

### Table of Contents
You're sections headers will be used to reference location of destination.

- [Description](#description)
- [How To Use](#how-to-use)
- [References](#references)
- [License](#license)
- [Author Info](#author-info)

---

## Description

Creating ReadMe's for your Github repository can be tedious.  I hope this template can save you time and effort as well as provide you with some consistency across your projects.

#### Technologies

- Technology 1
- html
- css
- php
- wordpress
- custom post types
- ACF
- jquery
- https://www.npmjs.com/package/jquery-validation
- https://www.npmjs.com/package/grunt-acf
- https://docs.belin.io/webstorage.hx/installation/


[Back To The Top](#read-me-template)

---

## How To Use

#### Installation



#### API Reference

```html
    <p>dummy code</p>
```
[Back To The Top](#read-me-template)

---

## References
[Back To The Top](#read-me-template)

---

## License

MIT License

Copyright (c) [2017] [James Q Quick]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

[Back To The Top](#read-me-template)

---

## Author Info

- Twitter - [@shaunpalmer](https://twitter.com/shaunpalmer)
- Website - [shaun palmer](https://projectstudios.co.nz/)

[Back To The Top](#read-me-template)

how use this read-me-template >> https://www.youtube.com/watch?v=eVGEea7adDM
